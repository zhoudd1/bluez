#!/bin/bash
./configure --host=arm-linux-gnueabihf \
--prefix=/usr/local/bluez \
CC="arm-linux-gnueabihf-gcc \
-L/usr/local/bluez/lib \
-I/usr/local/bluez/include \
-I/usr/local/bluez/include/glib-2.0 \
-I/usr/local/bluez/include/dbus-1.0 \
-I/usr/local/bluez/lib/glib-2.0/include \
-I/usr/local/bluez/lib/dbus-1.0/include \
-I/usr/local/bluez/lib/libffi-3.0.13/include " \
PKG_CONFIG_PATH=/usr/local/bluez/lib/pkgconfig \
CPPFLAGS='-I/usr/local/bluez/include/' \
CFLAGS='-I/usr/local/bluez/include/' \
LDFLAGS='-lrt -lreadline -lncurses -L/usr/local/bluez/lib' \
--disable-systemd --disable-udev --disable-cups --enable-library 

make
if [ $? == 0 ]; then
	make install
else
	echo -e "\n\tmake fail\n"
fi

