#!/bin/bash
./configure --host=arm-linux-gnueabihf --prefix=/usr/local/bluez bash_cv_wcwidth_broken=yes \
PKG_CONFIG_PATH=/usr/local/bluez/lib/pkgconfig \
CPPFLAGS='-I/usr/local/bluez/include/' \
CFLAGS='-I/usr/local/bluez/include/' \
LDFLAGS='-lncurses -L/usr/local/bluez/lib'

#make SHLIB_LIBS=-lncurses
make
if [ $? == 0 ]; then
	make install
else
	echo -e "\n\tmake fail\n"
fi
