#!/bin/bash
cd /home/dong/bluez/ncurses-5.9
./configure --prefix=/usr/local/bluez --with-shared \
CC=arm-linux-gnueabihf-gcc \
CXX=arm-linux-gnueabihf-g++ \
--host=arm-linux-gnueabihf

make
if [ $? == 0 ]; then
	make install
else
	echo -e "\n\tmake fail\n"
fi
